document.querySelector(".open").addEventListener("click", () => {
  const overlay = document.getElementById("overLay");
  overLay.classList.toggle("active");
});
